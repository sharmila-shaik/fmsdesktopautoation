package com.allica.Utilities;

import java.io.IOException;
import  java.sql.Connection;		
import  java.sql.Statement;		
import  java.sql.ResultSet;		
import  java.sql.DriverManager;		
import  java.sql.SQLException;	

public class JDBCConnection {
	public static void  main(String[] args) throws  ClassNotFoundException, SQLException, Exception {													
		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		
//Runtime.getRuntime().exec("C:\\Windows\\system32\\mstsc.exe");
		String ip = "192.168.34.6";
//		//Deleting credentials
//		Process p1 = Runtime.getRuntime().exec("cmdkey /delete:" + ip);
//		p1.destroy();
//		
		
		String userName="civbdev\\disha.harish";
		String password="Apples100!";
Process p = Runtime.getRuntime().exec("cmdkey /generic:192.168.34.6 /user:" + userName +" /pass:" + password);
	//	Process p =	Runtime.getRuntime().exec("cmdkey.exe /generic:192.168.34.6 /user:civbdev\\disha.harish /pass:Apples100!");
Thread.sleep(20000);
		
		p.destroy();

Runtime.getRuntime().exec("mstsc /v: " + ip + " /f /console");
//Runtime.getRuntime().exec("mstsc /v: " + ip );

Thread.sleep(2*60*1000); // Minutes seconds milliseconds

		
//		Thread.sleep(2000);
//		Runtime.getRuntime().exec("C:\\Users\\lakhwinder_singh\\Desktop\\AutoIt\\RemoteHandle.exe"); 
//		Thread.sleep(2000);
//		
//		Runtime.getRuntime().exec("C:\\Users\\lakhwinder_singh\\Desktop\\AutoIt\\demoa.exe"); 
        	String dbUrl =  "jdbc:sqlserver://uat-bl-db-01.civbdev.local:1433;DatabaseName=UTIL";
		
		//Database Username		
		String username = "Maveric_testing";	
        
		//Database Password		
		String password1 = "Apples100!";				

		//Query to Execute		
		String query = "SELECT [AD].[application_id] ,[AD].[broker_id] ,JSON_QUERY(AD.[data], '$') Data ,[AD].borrower_type ,[AD].[created_at]   ,[Documents].[file_name] ,[Documents].[upload_type] ,[Documents].[attachment_type]  ,[Documents].[notes] ,[Documents].[attachment_filename_or_url]  ,[Documents].[alt_attachment_filename_or_url] ,[Documents].[created_at] FROM [non_ltd_borrowers].[application_data] AD LEFT JOIN [non_ltd_borrowers].[application_documents] Documents ON AD.application_id = Documents.application_id AND AD.application_id = 'MTU4MjA0MTk5OTU4OVNJVDE5OTA=' FOR JSON AUTO";	
        
 	    //Load mysql jdbc driver		
   	  //  Class.forName("com.mysql.cj.jdbc.Driver");	
   	 Class.forName("net.sourceforge.jtds.jdbc.Driver");
   
   		//Create Connection to DB		
    	Connection con = DriverManager.getConnection(dbUrl,username,password1);
  
  		//Create Statement Object		
	   Statement stmt = con.createStatement();					

			// Execute the SQL Query. Store results in ResultSet		
 		ResultSet rs= stmt.executeQuery(query);							
 
 		// While Loop to iterate through all data and print results		
		while (rs.next()){
	        		String appID = rs.getString(1);								        
                    String appRef = rs.getString(2);					                               
                    System. out.println(appID+"  "+appRef);		
            }		
			 // closing DB Connection		
			con.close();			
}
}
