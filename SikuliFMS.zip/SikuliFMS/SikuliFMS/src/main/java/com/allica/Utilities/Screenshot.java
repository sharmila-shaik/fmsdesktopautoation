package com.allica.Utilities;

import org.openqa.selenium.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static javax.imageio.ImageIO.read;
import static javax.imageio.ImageIO.write;
import static org.apache.commons.io.FileUtils.*;

public class Screenshot {
	public static String screenshotPath = "";
	protected File screenshot;
	protected File screenshotLocation;
	protected BufferedImage fullSizeImage;
	protected String fileName;
	protected String filePath;
	protected String defaultFileName = "screenshot";
	protected static final String FORMAT_PATTERN = "%s%s.png";
	protected String defaultFilePath = "S:\\Testers\\Digital Testing\\WebAutomation\\Screenshots\\";
	protected WebElement element;
	protected WebDriver driver;
	public static String timeStamp = "";

	public Screenshot(WebDriver driver) {
		this.driver = driver;
	}

	// ----------Set Screenshot name & path------------

	private String checkNullFields() {
		timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String defaultFilePath = System.getProperty("user.dir") + "/Screenshots/";
	//	String defaultFilePath = "S:\\Testers\\Digital Testing\\WebAutomation\\Screenshots\\";
		String defaultFileName = "screenshot" + timeStamp;
		if (fileName == null && filePath == null) {
			screenshotLocation = new File(java.lang.String.format(FORMAT_PATTERN, defaultFilePath, defaultFileName));
		} else if (fileName == null) {
			screenshotLocation = new File(java.lang.String.format(FORMAT_PATTERN, filePath, defaultFileName));
		} else if (filePath == null) {
			screenshotLocation = new File(String.format(FORMAT_PATTERN, defaultFilePath, fileName));
		} else {
			screenshotLocation = new File(java.lang.String.format(FORMAT_PATTERN, filePath, fileName));
		}
		return screenshotPath = defaultFilePath + defaultFileName + ".png";
	}

	// ----------------------- Take Screenshot -------------------
	public String takeFullSizeScreenShot(WebDriver driver) throws IOException {
		screenshotPath = checkNullFields();
		screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		fullSizeImage = read(screenshot);
		write(fullSizeImage, "png", screenshotLocation);
		return screenshotPath;
	}

	// Highlight the Current Element and unhighlight the last element
	// and then take screenshot
	public String getScreenshot(WebElement element, WebElement lastElement, WebDriver driver)
			throws IOException, InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].style.border='4px solid blue'", element);
		// jse.executeScript("arguments[0].setAttribute('style', 'background: yellow;
		// border: 2px solid blue;');", element);
		if (lastElement != null) {
			try {
				jse.executeScript("arguments[0].style.border='0px'", lastElement);
			} catch (StaleElementReferenceException ignored) {
			} finally {
				lastElement = null;
			}
		}
		screenshotPath = takeFullSizeScreenShot(driver);
		copyFile(screenshot, screenshotLocation);
		return screenshotPath;
	}

	// Highlight the Current element including previous element if highlighted
	// and then take screenshot
	public String getScreenshot(WebElement element, WebDriver driver) throws IOException, InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].style.border='4px solid blue'", element);
		screenshotPath = takeFullSizeScreenShot(driver);
		copyFile(screenshot, screenshotLocation);
		return screenshotPath;
	}

	// ---------Only Screenshot without highlight---
	public String getScreenshot(WebDriver driver) throws IOException, InterruptedException {
		screenshotPath = takeFullSizeScreenShot(driver);
		copyFile(screenshot, screenshotLocation);
		return screenshotPath;
	}
}
