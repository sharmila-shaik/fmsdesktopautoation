package com.allica.Utilities;

public class ZephyrConnection {

}
