package com.allica.Utilities;

import org.openqa.selenium.*;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentReportMethods {
	ExtentReports extent;
	ExtentTest logger;
	protected WebDriver driver;
	public static String timeStamp = "";
	public static int flag = 0;
	public static String testCase = "";

	// Create a New Report if this is the first Test Scenario
	public ExtentReports setHTMLTrueExtentReport() throws IOException, InterruptedException {

		if (flag == 0) {
			timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		}
		 extent = new ExtentReports(
		 System.getProperty("user.dir") + "/test-output/AllicaExtentReport" +
		 timeStamp + ".html", true);
//		extent = new ExtentReports(
//				"S:\\Testers\\Digital Testing\\WebAutomation\\TestOutput\\AllicaExtentReport" + timeStamp + ".html",
//				true);
		extent.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
		return extent;
	}

	// Suffix the report if this is not the First Scenario
	public ExtentReports setHTMLFalseExtentReport(ExtentReports extent, String tc)
			throws IOException, InterruptedException {
		testCase = tc;
		if (!testCase.startsWith("PR.")) {
		testCase = tc;
		 extent = new ExtentReports(
		 System.getProperty("user.dir") + "/test-output/AllicaExtentReport" +
		 timeStamp + ".html", false);
//		extent = new ExtentReports(
//				"S:\\Testers\\Digital Testing\\WebAutomation\\TestOutput\\AllicaExtentReport" + timeStamp + ".html",
//				false);
		extent.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
		flag = 1;}
		return extent;

	}

	// End the Test Case Unit
	public ExtentReports flushExtentReport(ExtentReports extent, ExtentTest logger)
			throws IOException, InterruptedException {
		if (!testCase.startsWith("PR.")) {
			extent.endTest(logger);
			extent.flush();
			extent.close();
		}
		return extent;
	}
}
