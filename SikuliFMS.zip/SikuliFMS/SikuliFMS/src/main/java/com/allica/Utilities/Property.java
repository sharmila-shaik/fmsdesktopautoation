//-----Author : ShivaShankar-----//
package com.allica.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Property {
	
	static Properties prop = new Properties();

	public static String getPropertyValue(String value)
	{
		File file = new File("./config.properties");
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			prop.load(fileInput);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String returnValue = prop.getProperty(value);
		System.out.println(returnValue);
		return returnValue;

	}
}
