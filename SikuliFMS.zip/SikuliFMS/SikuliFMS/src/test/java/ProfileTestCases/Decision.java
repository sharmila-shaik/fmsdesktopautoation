package ProfileTestCases;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class Decision {

	public static void main(String[] args) throws InterruptedException, FindFailed, MalformedURLException {
				WiniumDriver driver;
				Screen s = new Screen();
				DesktopOptions options = new DesktopOptions();
				
				options.setApplicationPath("S:\\FMS_Next App UAT\\Client\\Profile.FMS.Client.exe");
				 driver = new WiniumDriver(new URL("http://localhost:9999"), options);
				 
				   //s.click(System.getProperty("user.dir") + "\\images\\submodules.PNG");
					//Thread.sleep(4000);
					//((System.getProperty("user.dir") + "\\images\\submodules.PNG"), 90);
					
					
					Pattern MaxFms = new Pattern((System.getProperty("user.dir") +"\\images\\MaxFms.PNG"));
					 waitForImage((System.getProperty("user.dir") + "\\images\\MaxFms.PNG"), 90);
					  s.click(MaxFms);
					  Thread.sleep(5000);
		/*
		 * Region r= s.find((System.getProperty("user.dir")
		 * +"\\images\\ProfileALLF.PNG")); r.x=r.x+50; Thread.sleep(5000); s.click(r);
		 * Thread.sleep(2000);
		 */
				 
				  Pattern DynamicFields = new Pattern((System.getProperty("user.dir") + "\\images\\DynamicFields.PNG"));
					
					waitForImage((System.getProperty("user.dir") + "\\images\\DynamicFields.PNG"), 150);
					s.doubleClick(DynamicFields);
				Thread.sleep(2000);
				
				Pattern DynamicAccepts = new Pattern((System.getProperty("user.dir") + "\\images\\Dynamic Accept.PNG"));
				
				waitForImage((System.getProperty("user.dir") + "\\images\\Dynamic Accept.PNG"), 150);
				s.doubleClick(DynamicAccepts);
			Thread.sleep(2000);
				
			}
			


private static void waitForImage(String imageName, int time) throws InterruptedException{
    for(int i=0; i<1; i++){
        if(isImagePresent(imageName)){
            break;
        }
        else{
            Thread.sleep(3000);
        }
    }
}


private static boolean isImagePresent(String imageName) {
 boolean status = false;
   Screen s = new Screen();
    try {
        s.find(imageName);
        status = true;
    } 
    catch (FindFailed e) {
       System.out.println("Image not present");
        e.printStackTrace();
    }
    return status;
} 
}


