package ProfileTestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class Workflow {

	public static void main(String[] args) throws MalformedURLException, InterruptedException, FindFailed, AWTException {
		ExtentTest logger = null;
		WiniumDriver driver;
		DesktopOptions options = new DesktopOptions();
		options.setApplicationPath("S:\\FMS_Next App UAT\\Client\\Profile.FMS.Client.exe");
		driver = new WiniumDriver(new URL("http://localhost:9999"), options);
		Thread.sleep(10000);
		driver.findElementByClassName("TextBox").sendKeys("KYCB_SET1");
		driver.findElementByClassName("PasswordBoxEdit").sendKeys("123456");
		driver.findElement(By.id("cmdOK")).click();
		Thread.sleep(20000);
		
		
		WebElement webEle = driver.findElementByName("Deposits");
		Actions act = new Actions(driver);
        act.doubleClick(webEle);       								
        Thread.sleep(20000);
        
        act.doubleClick().build().perform();
        
        act.doubleClick().build().perform();
        WebElement webEle1 =    driver.findElementByName("New Account Application");
        act.doubleClick(webEle1);       
        Thread.sleep(20000);
       
        act.doubleClick().build().perform();
        System.out.println("inside");
        act.doubleClick().build().perform();
        Thread.sleep(20000);
       // driver.findElementByName("DocumentGroup").sendKeys("testing123");
        
        
        
      //skuli
    	Robot robot = new Robot();
    	Screen s = new Screen();
        //Pattern pAppReferenceNo = new Pattern((System.getProperty("user.dir") + "\\images\\AppReferenceNo.PNG"));
        driver.findElementByName("DocumentGroup").sendKeys("830859D0AC6AD6");
		//s.type(pAppReferenceNo, Key.ESC);
		//File path1 = new File("pAppReferenceNo");
		//String pathFA1 = "853086B35389CD";
		/*
		 * StringSelection stringSelection1 = new StringSelection(pathFA1);
		 * System.out.println(pathFA1); Clipboard clipboard1 =
		 * Toolkit.getDefaultToolkit().getSystemClipboard();
		 * clipboard1.setContents(stringSelection1, null); Thread.sleep(5000);
		 * robot.keyPress(KeyEvent.VK_ESCAPE); robot.keyRelease(KeyEvent.VK_ESCAPE);
		 * robot.keyPress(KeyEvent.VK_CONTROL); robot.keyPress(KeyEvent.VK_V);
		 * robot.keyRelease(KeyEvent.VK_V); robot.keyRelease(KeyEvent.VK_CONTROL);
		 */
		
		//Thread.sleep(1000);
		//s.type(pAppReferenceNo, "770DA0560A0C8D");
		
		Pattern pRetriveNewDepositsApp = new Pattern((System.getProperty("user.dir") + "\\images\\RetriveButton.PNG"));
		//s.doubleClick(pRetriveNewDepositsApp);
		waitForImage((System.getProperty("user.dir") + "\\images\\RetriveButton.PNG"), 150);
		s.doubleClick(pRetriveNewDepositsApp);
		//waitForImage((System.getProperty("user.dir") + "\\images\\RetriveButton.PNG"), 150);
		//Thread.sleep(6000);
		Thread.sleep(5000);
		
//****************************************************KYCB Additional Documents***************************************************************************	
		s.click(System.getProperty("user.dir") + "\\images\\submodules.PNG");
		
		System.out.println("inside submodule");
		waitForImage((System.getProperty("user.dir") + "\\images\\submodules.PNG"), 90);
		//Thread.sleep(3000);
		Pattern stepDocu1 = new Pattern((System.getProperty("user.dir") + "\\images\\SDoc1.PNG"));
		s.doubleClick(stepDocu1);
		
		waitForImage((System.getProperty("user.dir") + "\\images\\SDoc1.PNG"), 90);
		//Thread.sleep(3000);
		
		Pattern stepDocuCheck1BS = new Pattern((System.getProperty("user.dir") + "\\images\\SDocBs.PNG"));
		waitForImage((System.getProperty("user.dir") + "\\images\\SDocBs.PNG"), 150);
		s.click(stepDocuCheck1BS);
		//waitForImage((System.getProperty("user.dir") + "\\images\\SDocBs.PNG"), 120);
		
		Pattern stepDocuCheck1 = new Pattern((System.getProperty("user.dir") + "\\images\\SDoccheck1.PNG"));
		waitForImage((System.getProperty("user.dir") + "\\images\\SDoccheck1.PNG"), 150);
		s.click(stepDocuCheck1);
		
		waitForImage((System.getProperty("user.dir") + "\\images\\SDoccheck1.PNG"), 90);
		//Thread.sleep(4000);
		Pattern stepDocUpdate1 = new Pattern((System.getProperty("user.dir") + "\\images\\SDocUpdate1.PNG"));
		waitForImage((System.getProperty("user.dir") + "\\images\\SDocUpdate1.PNG"), 90);;
		s.doubleClick(stepDocUpdate1);
		
		waitForImage((System.getProperty("user.dir") + "\\images\\SDocUpdate1.PNG"), 90);
		
		s.click(System.getProperty("user.dir") + "\\images\\submodules.PNG");
		waitForImage((System.getProperty("user.dir") + "\\images\\submodules.PNG"), 90);
		//Thread.sleep(4000);
		
		
		Pattern stepAtion1 = new Pattern((System.getProperty("user.dir") + "\\images\\SAction1.PNG"));
		s.doubleClick(stepAtion1);
		waitForImage((System.getProperty("user.dir") + "\\images\\SAction1.PNG"), 90);
		
		//Thread.sleep(4000); 
		Pattern stepAtion1Stage = new Pattern((System.getProperty("user.dir") + "\\images\\SActionStage.PNG"));
		s.doubleClick(stepAtion1Stage);
		waitForImage((System.getProperty("user.dir") + "\\images\\SActionStage.PNG"), 90);
		
		
		Pattern stepAtionCheck1 = new Pattern((System.getProperty("user.dir") + "\\images\\SActionCheck1.PNG"));
		waitForImage((System.getProperty("user.dir") + "\\images\\SActionCheck1.PNG"), 120);
		s.click(stepAtionCheck1);
		waitForImage((System.getProperty("user.dir") + "\\images\\SActionCheck1.PNG"), 120);
		
		//Thread.sleep(4000);
		Pattern stepAtionUpdate1 = new Pattern((System.getProperty("user.dir") + "\\images\\SActionUpdate1.PNG"));
		s.doubleClick(stepAtionUpdate1);
		waitForImage((System.getProperty("user.dir") + "\\images\\SActionUpdate1.PNG"), 90);
		//Thread.sleep(4000);
		//s.waitVanish("SActionUpdate1.PNG", FOREVER);
		s.click(System.getProperty("user.dir") + "\\images\\submodules.PNG");
		//Thread.sleep(4000);
		waitForImage((System.getProperty("user.dir") + "\\images\\submodules.PNG"), 90);
		
		Pattern MainModule1 = new Pattern((System.getProperty("user.dir") + "\\images\\Main Module1.PNG"));
		s.doubleClick(MainModule1);
		waitForImage((System.getProperty("user.dir") + "\\images\\Main Module1.PNG"), 90);
		
		Thread.sleep(1000);
		//driver.quit();
		//Thread.sleep(10000);
		//driver.findElement(By.name("OK")).click();
		//Thread.sleep(5000);
		
		//********************************KYCB Descison ******************************************************************
		
		
		
		
		//*********************************Log out *******************************************************************************//
		
		/*Pattern MinFms = new Pattern((System.getProperty("user.dir") +"\\images\\MinFms.PNG"));
		  waitForImage((System.getProperty("user.dir") + "\\images\\MinFms.PNG"), 90);
		  s.doubleClick(MinFms);
		  
		  s.click(System.getProperty("user.dir") + "\\images\\ProfileExit.PNG");
		  //Thread.sleep(4000);
		  waitForImage((System.getProperty("user.dir") + "\\images\\ProfileExit.PNG"), 90);
		
		  Pattern close = new Pattern((System.getProperty("user.dir") +"\\images\\crossButton.PNG"));
		  waitForImage((System.getProperty("user.dir") + "\\images\\crossButton.PNG"), 90);
		  s.doubleClick(close);*/
		 
		  Region r= s.find((System.getProperty("user.dir") +"\\images\\ProfileALLF.PNG"));
		  r.x=r.x+120;
		  Thread.sleep(5000);
		  s.click(r);
		  
		  Thread.sleep(2000);
		  
		  Pattern clickOkclose = new Pattern((System.getProperty("user.dir") +"\\images\\MinOk.PNG")); 
		  Thread.sleep(2000);
		  //waitForImage((System.getProperty("user.dir") + "\\images\\OK ButtonC.PNG"), 90);
		  s.doubleClick(clickOkclose);
		  Thread.sleep(2000);

		  Pattern question = new Pattern((System.getProperty("user.dir") +"\\images\\question.PNG")); 
		  Thread.sleep(2000);
		 // waitForImage((System.getProperty("user.dir") + "\\images\\OK ButtonC.PNG"), 90);
		  s.click(question);								
		  Thread.sleep(3000);
		  
		 //Pattern Okexit = new Pattern((System.getProperty("user.dir") +"\\images\\OKbutton1.PNG")); 
		 driver.findElement(By.name("OK")).click();
		  Thread.sleep(2000);
		 // waitForImage((System.getProperty("user.dir") + "\\images\\OK ButtonC.PNG"), 90);
		  //s.click(Okexit);

		  
		 
		//**************************************
		  Thread.sleep(1000);
			options.setApplicationPath("S:\\FMS_Next App UAT\\Client\\Profile.FMS.Client.exe");
			driver = new WiniumDriver(new URL("http://localhost:9999"), options);
			Thread.sleep(10000);
			driver.findElementByClassName("TextBox").sendKeys("HOO_SET3");
			driver.findElementByClassName("PasswordBoxEdit").sendKeys("123456");
			driver.findElement(By.id("cmdOK")).click();
			Thread.sleep(20000);
			
			
			WebElement webEle11 = driver.findElementByName("Deposits");
			Actions act1 = new Actions(driver);
	        act1.doubleClick(webEle11);       
	        Thread.sleep(20000);
	        act1.doubleClick().build().perform();
	        
	        WebElement webEle12 =    driver.findElementByName("New Account Application");
	        act1.doubleClick(webEle12);       
	        Thread.sleep(20000);
	        act1.doubleClick().build().perform();
	        Thread.sleep(20000);
	        driver.findElementByName("DocumentGroup").sendKeys("830859D0AC6AD6");
		
	
	}
	private static void waitForImage(String imageName, int time) throws InterruptedException{
        for(int i=0; i<1; i++){
            if(isImagePresent(imageName)){
                break;
            }
            else{
                Thread.sleep(3000);
            }
        }
    }


private static boolean isImagePresent(String imageName) {
	 boolean status = false;
       Screen s = new Screen();
        try {
            s.find(imageName);
            status = true;
        } 
        catch (FindFailed e) {
           System.out.println("Image not present");
            e.printStackTrace();
        }
        return status;
    } 
}
